This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

This is implementation of Tetris Game but using words. arrange letters and make english language words, once you have valid word, click on letter to score points.

Game play video ==> https://youtu.be/qvoL5J-jsFA

This is a PWA. Play and Have fun.

All suggestion and issues are welcome -:) 

Thank You!
